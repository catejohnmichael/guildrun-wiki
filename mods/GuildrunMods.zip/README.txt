Guildrun mods for Guildrun Demo 0.5.10 (MelonLoader 0.7.3)
Full instructions: https://catejohnmichael.github.io/guildrun-wiki/mods.html

AlwaysOnGrid v1.0.0: Placement grid stays visible in Shop and Placement, no hero lift needed.
EventPanelMover v1.1.0: Moves the Event/Challenge banner off the top enemies' HP bars, to under the speed buttons.
BattleRecorder v1.0.3: Saves every fight to JSON: each hit, heal, status and death with its source. Open in the Fight viewer.
SaveStates v1.0.3: Solo save states: auto-checkpoint at every fight, reload to replay it with a different lineup.
StartingRerolls v1.0.0: Every new run starts with at least 2 starting-hero rerolls (Bonus Tokens).
QualityOnly v1.0.1: Every starting bonus is Quality over Quantity, rerolls included.
QuantityOnly v1.0.0: Every starting bonus is Quantity over Quality, rerolls included.
DoublePenalty v1.0.0: Quality over Quantity becomes Hard Mode: 2 heroes and 1 fewer item slot.
StreakFreeze v1.0.0: Stops the Red Rift win streak counter: wins and losses no longer change it.
TurboSpeed v1.0.0: Fight speeds become 1.6x / 2.5x / 5x: drops the slowest, adds one twice the old fastest.
SellLastHero v1.0.1: Sell your last hero in the shop, e.g. to buy a different one.

INSTALL
1. Install MelonLoader v0.7.3 with its official installer:
   https://github.com/LavaGang/MelonLoader/releases/tag/v0.7.3  (select Guildrun.exe, click INSTALL)
2. Start Guildrun once, let it reach the main menu, then quit.
3. Copy the .dll files from this zip's Mods folder into the Mods folder in the Guildrun Demo folder.
4. Play normally from Steam.

Settings: Guildrun Demo\UserData\MelonPreferences.cfg (restart the game after editing).
Uninstall: delete the .dll files from Mods.
