Guildrun mods for Guildrun Demo 0.5.10 (MelonLoader 0.7.3)
Full instructions: https://catejohnmichael.github.io/guildrun-wiki/mods.html

AlwaysOnGrid v1.0.0: Keeps the placement grid visible while you position heroes, so you no longer have to lift a hero to see it.
EventPanelMover v1.1.0: Moves the Event Effect / Challenge banner out from under the fight timer, where it covers the top enemies' HP bars.
BattleRecorder v1.0.2: Records every fight to a file: every hit, heal, status effect and death, with the hero, enemy, item, relic or ability behind it. Review them in the Fight viewer.
SaveStates v1.0.2: Save states for solo runs: every fight's start is checkpointed automatically, and you can reload any checkpoint to replay that fight with a different lineup.
StartingRerolls v1.0.0: Every new run starts with at least 2 rerolls of the starting-hero pick.

INSTALL
1. Install MelonLoader v0.7.3 with its official installer:
   https://github.com/LavaGang/MelonLoader/releases/tag/v0.7.3  (select Guildrun.exe, click INSTALL)
2. Start Guildrun once, let it reach the main menu, then quit.
3. Copy the .dll files from this zip's Mods folder into the Mods folder in the Guildrun Demo folder.
4. Play normally from Steam.

Settings: Guildrun Demo\UserData\MelonPreferences.cfg (restart the game after editing).
Uninstall: delete the .dll files from Mods.
